import os
import bisect

# --- Configuration ---
# TODO: Change these values to match your setup
NUM_FILES = 21
FILE_PREFIX = "sweep"  # Assumes files are named e.g., "log_file_0.txt", "log_file_1.txt", ...
FILE_SUFFIX = ".txt"
SOLUTION_BY_ITER_OUTPUT_FILE = FILE_PREFIX+"_solutions_by_iteration.txt"
SOLUTION_BY_TIME_OUTPUT_FILE = FILE_PREFIX+"solutions_by_time.txt" # New output file
PLACEHOLDER = "NA" # Value to use if no solution has been found yet for a given run

def process_log_files():
    """
    Reads multiple log files, processes the data to align solutions by both
    iteration and time, and writes two summary output files.
    """
    all_files_data = []
    master_iterations_set = set()
    master_times_set = set() # New set to collect all unique timestamps

    print("--- Reading and parsing input files ---")
    for i in range(NUM_FILES):
        filename = f"{FILE_PREFIX}{i}{FILE_SUFFIX}"
        file_data = {'iters': [], 'times': [], 'sols': []}
        timeShift = False
        previousTime = 0
        try:
            with open(filename, 'r') as f:
                for line in f:
                    try:
                        parts = line.strip().split()
                        iteration = int(parts[0])
                        time_ms = int(parts[1])
                        solution = float(parts[2])
                        if iteration > 20000 and (time_ms*1.0) / iteration < 20.0 and i != 21:
                            timeShift = True
                        if timeShift:
                            time_ms += 18003761 # Fix where windows shifted the clock into the past at some pint
                        if timeShift and (time_ms*1.0) / iteration > 30.0:
                            print('uh oh')

                        file_data['iters'].append(iteration)
                        file_data['times'].append(time_ms)
                        file_data['sols'].append(solution)
                        
                        master_iterations_set.add(iteration)
                        master_times_set.add(time_ms) # Add the time to our new set
                    except (ValueError, IndexError):
                        print(f"Warning: Skipping malformed line in {filename}: '{line.strip()}'")
            print(f"Successfully read {filename}")
        except FileNotFoundError:
            print(f"Warning: File {filename} not found. It will be skipped.")
        
        all_files_data.append(file_data)

    if not master_iterations_set:
        print("Error: No data found in any files. Exiting.")
        return

    # --- 1. Generate the solutions_by_iteration.txt file (same as before) ---
    sorted_master_iterations = sorted(list(master_iterations_set))
    print(f"\nFound {len(sorted_master_iterations)} unique iteration points. Generating {SOLUTION_BY_ITER_OUTPUT_FILE}...")
    
    with open(SOLUTION_BY_ITER_OUTPUT_FILE, 'w') as f_sol_iter:
        header_cols = [f"Run_{i}" for i in range(NUM_FILES)]
        f_sol_iter.write(f"Iteration {' '.join(header_cols)}\n")

        for iteration in sorted_master_iterations:
            line_parts = [str(iteration)]
            for file_data in all_files_data:
                idx = bisect.bisect_right(file_data['iters'], iteration)
                if idx == 0:
                    line_parts.append(PLACEHOLDER)
                else:
                    line_parts.append(str(file_data['sols'][idx - 1]))
            f_sol_iter.write(" ".join(line_parts) + "\n")
    print("Done.")

    # --- 2. Generate the new solutions_by_time.txt file ---
    sorted_master_times = sorted(list(master_times_set))
    print(f"\nFound {len(sorted_master_times)} unique time points. Generating {SOLUTION_BY_TIME_OUTPUT_FILE}...")
    
    with open(SOLUTION_BY_TIME_OUTPUT_FILE, 'w') as f_sol_time:
        header_cols = [f"Run_{i}" for i in range(NUM_FILES)]
        f_sol_time.write(f"Time_ms {' '.join(header_cols)}\n")

        for time_ms in sorted_master_times:
            line_parts = [str(time_ms)]
            for file_data in all_files_data:
                # Use bisect on the 'times' list this time
                idx = bisect.bisect_right(file_data['times'], time_ms)
                if idx == 0:
                    line_parts.append(PLACEHOLDER)
                else:
                    # The solution is still retrieved from the 'sols' list at the found index
                    line_parts.append(str(file_data['sols'][idx - 1]))
            f_sol_time.write(" ".join(line_parts) + "\n")
    print("Done.")

    print("\n--- Processing complete! ---")


if __name__ == "__main__":
    process_log_files()